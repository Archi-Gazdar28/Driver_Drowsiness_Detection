"""
utils/display.py
All OpenCV drawing — HUD, contours, landmarks, alerts.
"""

import cv2
import numpy as np
from imutils import face_utils


def draw_frame(frame, cfg, shape, rect, ear, mar, closed_counter,
               drowsy, yawning, pitch, yaw, roll, fps):
    """Draw all overlays onto `frame` in-place."""

    h, w = frame.shape[:2]

    if shape is not None and rect is not None:
        _draw_face_box(frame, cfg, rect, drowsy)
        if cfg.SHOW_EYE_CONTOUR:
            _draw_eye_contours(frame, cfg, shape, drowsy)
        if cfg.SHOW_MOUTH_CONTOUR:
            _draw_mouth_contour(frame, cfg, shape, yawning)
        if cfg.SHOW_LANDMARKS:
            _draw_landmarks(frame, cfg, shape)

    if cfg.SHOW_HUD:
        _draw_hud(frame, cfg, ear, mar, closed_counter,
                  drowsy, yawning, pitch, yaw, roll, fps, w)

    if drowsy:
        _draw_alert_banner(frame, "! DROWSY — WAKE UP !", cfg.COLOR_ALERT, w, h)
    elif yawning:
        _draw_alert_banner(frame, "YAWNING DETECTED", cfg.COLOR_WARN, w, h)


# ── Internal ──────────────────────────────────────────────────────────────────

def _draw_face_box(frame, cfg, rect, drowsy):
    (bX, bY, bW, bH) = face_utils.rect_to_bb(rect)
    color = cfg.COLOR_ALERT if drowsy else cfg.COLOR_OK
    cv2.rectangle(frame, (bX, bY), (bX + bW, bY + bH), color, 2)


def _draw_eye_contours(frame, cfg, shape, drowsy):
    lS, lE = face_utils.FACIAL_LANDMARKS_IDXS["left_eye"]
    rS, rE = face_utils.FACIAL_LANDMARKS_IDXS["right_eye"]
    color  = cfg.COLOR_ALERT if drowsy else cfg.COLOR_OK
    for eye in [shape[lS:lE], shape[rS:rE]]:
        hull = cv2.convexHull(eye)
        cv2.drawContours(frame, [hull], -1, color, 1)


def _draw_mouth_contour(frame, cfg, shape, yawning):
    mouth = shape[49:68]
    hull  = cv2.convexHull(mouth)
    color = cfg.COLOR_WARN if yawning else cfg.COLOR_OK
    cv2.drawContours(frame, [hull], -1, color, 1)


def _draw_landmarks(frame, cfg, shape):
    KEY_INDICES = {33, 8, 36, 45, 48, 54}
    for i, (x, y) in enumerate(shape):
        color = cfg.COLOR_OK if i in KEY_INDICES else cfg.COLOR_LANDMARK
        cv2.circle(frame, (x, y), 1, color, -1)


def _draw_hud(frame, cfg, ear, mar, closed_counter,
              drowsy, yawning, pitch, yaw, roll, fps, frame_width):

    # Semi-transparent HUD background strip
    overlay = frame.copy()
    cv2.rectangle(overlay, (0, 0), (frame_width, 115), (0, 0, 0), -1)
    cv2.addWeighted(overlay, 0.45, frame, 0.55, 0, frame)

    font  = cv2.FONT_HERSHEY_SIMPLEX
    color = cfg.COLOR_OK

    # Row 1 — EAR / MAR
    ear_str = f"EAR: {ear:.3f}" if ear is not None else "EAR: ---"
    mar_str = f"MAR: {mar:.3f}" if mar is not None else "MAR: ---"
    ear_col = cfg.COLOR_ALERT if (ear is not None and ear < cfg.EAR_THRESH) else cfg.COLOR_OK
    mar_col = cfg.COLOR_WARN  if (mar is not None and mar > cfg.MAR_THRESH) else cfg.COLOR_OK
    cv2.putText(frame, ear_str, (10, 28),  font, 0.70, ear_col, 2)
    cv2.putText(frame, mar_str, (200, 28), font, 0.70, mar_col, 2)

    # Row 2 — Closed frame counter
    cnt_col = cfg.COLOR_ALERT if drowsy else (cfg.COLOR_WARN if closed_counter > 0 else color)
    cv2.putText(frame, f"Closed Frames: {closed_counter}", (10, 58), font, 0.65, cnt_col, 2)

    # Row 3 — Head pose
    if pitch is not None:
        pose_str = f"P:{pitch:5.1f}  Y:{yaw:5.1f}  R:{roll:5.1f}"
        cv2.putText(frame, pose_str, (10, 86), font, 0.60, (180, 180, 180), 1)

    # FPS — top right
    cv2.putText(frame, f"FPS: {fps:.1f}", (frame_width - 130, 28), font, 0.65, (180, 180, 180), 1)

    # Status — top right, row 2
    if drowsy:
        status, scol = "DROWSY", cfg.COLOR_ALERT
    elif yawning:
        status, scol = "YAWNING", cfg.COLOR_WARN
    else:
        status, scol = "ALERT", cfg.COLOR_OK
    cv2.putText(frame, status, (frame_width - 130, 58), font, 0.65, scol, 2)

    # Threshold indicators (small bars)
    if ear is not None:
        _draw_bar(frame, 10,  100, 160, ear / 0.5, cfg.COLOR_ALERT if ear < cfg.EAR_THRESH else cfg.COLOR_OK, "EAR")
    if mar is not None:
        _draw_bar(frame, 200, 100, 160, min(mar / 1.0, 1.0), cfg.COLOR_WARN if mar > cfg.MAR_THRESH else cfg.COLOR_OK, "MAR")


def _draw_bar(frame, x, y, width, ratio, color, label):
    ratio = max(0.0, min(1.0, ratio))
    cv2.rectangle(frame, (x, y), (x + width, y + 8), (50, 50, 50), -1)
    cv2.rectangle(frame, (x, y), (x + int(width * ratio), y + 8), color, -1)


def _draw_alert_banner(frame, text, color, w, h):
    overlay = frame.copy()
    cv2.rectangle(overlay, (0, h // 2 - 50), (w, h // 2 + 50), (0, 0, 0), -1)
    cv2.addWeighted(overlay, 0.55, frame, 0.45, 0, frame)

    font  = cv2.FONT_HERSHEY_SIMPLEX
    scale = 1.4
    thick = 3
    (tw, th), _ = cv2.getTextSize(text, font, scale, thick)
    tx = (w - tw) // 2
    ty = h // 2 + th // 2
    # Glow effect
    cv2.putText(frame, text, (tx + 2, ty + 2), font, scale, (0, 0, 0), thick + 2)
    cv2.putText(frame, text, (tx, ty), font, scale, color, thick)
