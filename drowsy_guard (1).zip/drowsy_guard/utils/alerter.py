"""
utils/alerter.py
Handles audio + console alerts for drowsy / yawning events.
Uses pygame for audio if available, otherwise falls back to terminal beep.
"""

import time
import os
import threading


class Alerter:
    ALERT_COOLDOWN = 3.0   # seconds between repeated alerts

    def __init__(self, cfg):
        self.cfg        = cfg
        self._last_alert = 0.0
        self._sound_ok   = False
        self._sound      = None

        if cfg.SOUND_ENABLED:
            self._init_sound()

    def check(self, drowsy: bool, yawning: bool):
        now = time.time()
        if now - self._last_alert < self.ALERT_COOLDOWN:
            return

        if drowsy:
            self._trigger("DROWSY ALERT")
            self._last_alert = now
        elif yawning:
            self._trigger("YAWN ALERT")
            self._last_alert = now

    # ── Private ───────────────────────────────────────────────────────────

    def _init_sound(self):
        """Try to initialise pygame mixer for audio playback."""
        try:
            import pygame
            pygame.mixer.init()
            sound_path = self.cfg.SOUND_FILE
            if os.path.isfile(sound_path):
                self._sound   = pygame.mixer.Sound(sound_path)
                self._sound_ok = True
                print("[Alerter] Audio ready (pygame).")
            else:
                print(f"[Alerter] Sound file not found at {sound_path} — using beep fallback.")
        except ImportError:
            print("[Alerter] pygame not installed — using terminal beep.")
        except Exception as e:
            print(f"[Alerter] Audio init failed ({e}) — using terminal beep.")

    def _trigger(self, label: str):
        if self._sound_ok and self._sound:
            threading.Thread(target=self._sound.play, daemon=True).start()
        else:
            # Cross-platform terminal beep
            print(f"\a[ALERT] {label}", end="", flush=True)
