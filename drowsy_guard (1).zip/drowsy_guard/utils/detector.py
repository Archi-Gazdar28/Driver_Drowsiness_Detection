"""
utils/detector.py
Wraps dlib face detection + landmark prediction.
Returns EAR, MAR, head pose angles, and raw shape per frame.
"""

import os
import numpy as np
import cv2
import dlib
from imutils import face_utils
from scipy.spatial import distance as dist


class FaceDetector:
    def __init__(self, cfg):
        if not os.path.isfile(cfg.PREDICTOR_PATH):
            raise RuntimeError(
                f"Predictor not found at: {cfg.PREDICTOR_PATH}\n"
                "Download shape_predictor_68_face_landmarks.dat from dlib.net"
            )
        self.cfg       = cfg
        self.detector  = dlib.get_frontal_face_detector()
        self.predictor = dlib.shape_predictor(cfg.PREDICTOR_PATH)

        (self.lS, self.lE) = face_utils.FACIAL_LANDMARKS_IDXS["left_eye"]
        (self.rS, self.rE) = face_utils.FACIAL_LANDMARKS_IDXS["right_eye"]
        self.mS, self.mE   = 49, 68   # mouth

    # ── Public ────────────────────────────────────────────────────────────

    def process(self, frame):
        """
        Detect the largest face and compute metrics.
        Returns (ear, mar, pitch, yaw, roll, shape, rect) or None if no face.
        """
        # Ensure frame is a contiguous uint8 BGR array before conversion
        if frame is None:
            return None
        if not frame.flags['C_CONTIGUOUS']:
            frame = np.ascontiguousarray(frame)
        if frame.dtype != np.uint8:
            frame = frame.astype(np.uint8)

        # Convert to grayscale — handle both BGR and already-gray frames
        if len(frame.shape) == 3 and frame.shape[2] == 3:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        elif len(frame.shape) == 3 and frame.shape[2] == 4:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGRA2GRAY)
        else:
            gray = frame  # already grayscale

        # dlib requires a contiguous uint8 array
        gray  = np.ascontiguousarray(gray, dtype=np.uint8)
        rects = self.detector(gray, 0)

        if len(rects) == 0:
            return None

        # Use the largest face by area
        rect  = max(rects, key=lambda r: r.width() * r.height())
        shape = self.predictor(gray, rect)
        shape = face_utils.shape_to_np(shape)

        ear   = self._ear(shape)
        mar   = self._mar(shape)
        pitch, yaw, roll = self._head_pose(shape, gray.shape)

        return ear, mar, pitch, yaw, roll, shape, rect

    # ── Private ───────────────────────────────────────────────────────────

    def _ear(self, shape):
        left  = shape[self.lS:self.lE]
        right = shape[self.rS:self.rE]
        return (self._eye_ear(left) + self._eye_ear(right)) / 2.0

    @staticmethod
    def _eye_ear(eye):
        A = dist.euclidean(eye[1], eye[5])
        B = dist.euclidean(eye[2], eye[4])
        C = dist.euclidean(eye[0], eye[3])
        return (A + B) / (2.0 * C)

    def _mar(self, shape):
        mouth = shape[self.mS:self.mE]
        A = dist.euclidean(mouth[2], mouth[9])
        B = dist.euclidean(mouth[4], mouth[7])
        C = dist.euclidean(mouth[0], mouth[6])
        return (A + B) / (2.0 * C) if C > 0 else 0.0

    def _head_pose(self, shape, img_size):
        image_points = np.array([
            shape[33], shape[8],
            shape[36], shape[45],
            shape[48], shape[54],
        ], dtype="double")

        h, w = img_size[:2]
        focal = w
        cam_matrix = np.array([
            [focal, 0, w / 2],
            [0, focal, h / 2],
            [0, 0, 1]
        ], dtype="double")
        dist_coeffs = np.zeros((4, 1))

        success, rot_vec, trans_vec = cv2.solvePnP(
            self.cfg.MODEL_3D_POINTS, image_points,
            cam_matrix, dist_coeffs,
            flags=cv2.SOLVEPNP_ITERATIVE
        )
        if not success:
            return 0.0, 0.0, 0.0

        rot_mat, _ = cv2.Rodrigues(rot_vec)
        angles, _, _, _, _, _ = cv2.RQDecomp3x3(rot_mat)
        pitch, yaw, roll = angles[0], angles[1], angles[2]

        # Store for drawing
        self._last_rot_vec   = rot_vec
        self._last_trans_vec = trans_vec
        self._last_cam       = cam_matrix
        self._last_dist      = dist_coeffs
        self._last_nose      = (int(image_points[0][0]), int(image_points[0][1]))

        return pitch, yaw, roll

    def get_pose_axis_points(self):
        """Returns (nose_2d, axis_end_2d) for drawing head axis arrow."""
        if not hasattr(self, '_last_rot_vec'):
            return None, None
        pts, _ = cv2.projectPoints(
            np.array([(0.0, 0.0, 500.0)]),
            self._last_rot_vec, self._last_trans_vec,
            self._last_cam, self._last_dist
        )
        end = (int(pts[0][0][0]), int(pts[0][0][1]))
        return self._last_nose, end
