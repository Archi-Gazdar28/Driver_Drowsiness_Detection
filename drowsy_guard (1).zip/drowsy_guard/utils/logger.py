"""
utils/logger.py
Logs detection metrics to a timestamped CSV file in logs/.
"""

import csv
import os
import time
from datetime import datetime


class DrowsinessLogger:
    FIELDS = ["timestamp", "ear", "mar", "closed_frames",
              "drowsy", "yawning", "pitch", "yaw", "roll"]

    def __init__(self, cfg):
        os.makedirs(cfg.LOG_DIR, exist_ok=True)
        ts       = datetime.now().strftime("%Y%m%d_%H%M%S")
        filepath = os.path.join(cfg.LOG_DIR, f"session_{ts}.csv")

        self._file   = open(filepath, "w", newline="")
        self._writer = csv.DictWriter(self._file, fieldnames=self.FIELDS)
        self._writer.writeheader()
        self._filepath = filepath
        print(f"[Logger] Logging to {filepath}")

    def log(self, ear, mar, closed_frames, drowsy, yawning, pitch, yaw, roll):
        self._writer.writerow({
            "timestamp":    datetime.now().isoformat(timespec="milliseconds"),
            "ear":          f"{ear:.4f}",
            "mar":          f"{mar:.4f}",
            "closed_frames": closed_frames,
            "drowsy":       int(drowsy),
            "yawning":      int(yawning),
            "pitch":        f"{pitch:.2f}" if pitch is not None else "",
            "yaw":          f"{yaw:.2f}"   if yaw   is not None else "",
            "roll":         f"{roll:.2f}"  if roll   is not None else "",
        })
        self._file.flush()   # write immediately so no data lost on crash

    def close(self):
        self._file.close()
        print(f"[Logger] Session saved → {self._filepath}")
